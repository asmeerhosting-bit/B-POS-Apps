(function () {
  if (window.__btInstallUI) return;
  window.__btInstallUI = 1;

  var CFG = {
    name: "B-POS",
    exe: "/downloads/B-POS-Setup.exe",
    apk: "/downloads/B-POS.apk"
  };

  var standalone = (window.matchMedia && matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone;
  if (standalone) return;

  var deferred = null;
  window.addEventListener("beforeinstallprompt", function (e) {
    e.preventDefault();
    deferred = e;
  });
  window.addEventListener("appinstalled", function () {
    var b = document.getElementById("btDlBtn");
    if (b) b.style.display = "none";
    close();
  });

  function el(tag, css, html) {
    var n = document.createElement(tag);
    if (css) n.style.cssText = css;
    if (html) n.innerHTML = html;
    return n;
  }

  function row(title, sub) {
    var r = el("div", "display:flex;align-items:center;gap:10px;justify-content:space-between;padding:12px 0;border-top:1px solid #e3e3e3");
    var t = el("div", "min-width:0", '<div style="font-weight:600;color:#0E5A2A;font-size:15px">' + title + '</div><div style="font-size:12px;color:#666;margin-top:2px">' + sub + "</div>");
    r.appendChild(t);
    return r;
  }

  function btnCss(on) {
    return "flex:none;border:0;border-radius:8px;padding:9px 14px;font-size:14px;font-weight:600;text-decoration:none;cursor:pointer;" +
      (on ? "background:#14803C;color:#fff" : "background:#ddd;color:#777;cursor:default");
  }

  var overlay, msg;

  function close() {
    if (overlay) overlay.style.display = "none";
  }

  function checkFile(url, a) {
    fetch(url, { method: "HEAD", cache: "no-store" }).then(function (r) {
      var ct = r.headers.get("content-type") || "";
      if (r.ok && ct.indexOf("text/html") === -1) {
        a.style.cssText = btnCss(true);
        a.textContent = "Download";
        a.setAttribute("href", url);
        a.setAttribute("download", "");
      } else {
        a.textContent = "Not uploaded";
      }
    }).catch(function () { a.textContent = "Not uploaded"; });
  }

  function build() {
    overlay = el("div", "position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,.45);z-index:2147483000;display:none;align-items:center;justify-content:center;padding:16px;font-family:system-ui,'Segoe UI',sans-serif");
    var card = el("div", "background:#fff;border-radius:14px;max-width:380px;width:100%;padding:18px 18px 12px;box-shadow:0 10px 30px rgba(0,0,0,.3)");
    var head = el("div", "display:flex;align-items:center;justify-content:space-between;margin-bottom:6px");
    head.appendChild(el("div", "font-size:18px;font-weight:700;color:#14803C", CFG.name + " app"));
    var x = el("button", "border:0;background:none;font-size:22px;cursor:pointer;color:#555", "&times;");
    x.setAttribute("aria-label", "Close");
    x.onclick = close;
    head.appendChild(x);
    card.appendChild(head);

    var r1 = row("Install from browser", "Windows, Android, Mac (Chrome / Edge)");
    var b1 = el("button", btnCss(true), "Install");
    b1.onclick = function () {
      if (deferred) {
        deferred.prompt();
        deferred.userChoice.then(function () { deferred = null; });
      } else {
        msg.style.display = "block";
      }
    };
    r1.appendChild(b1);
    card.appendChild(r1);

    var r2 = row("Windows app", "Installer (.exe) for Windows PC");
    var a2 = el("a", btnCss(false), "Checking...");
    r2.appendChild(a2);
    card.appendChild(r2);
    checkFile(CFG.exe, a2);

    var r3 = row("Android app", "APK file for Android phone");
    var a3 = el("a", btnCss(false), "Checking...");
    r3.appendChild(a3);
    card.appendChild(r3);
    checkFile(CFG.apk, a3);

    msg = el("div", "display:none;margin-top:8px;padding:10px;background:#FFF6CC;border-radius:8px;font-size:13px;color:#4a3b00;line-height:1.5",
      "The browser has not offered install yet. Use the browser menu: <b>Chrome / Edge</b> menu, then <b>Install " + CFG.name + "</b>. On iPhone: <b>Share</b>, then <b>Add to Home Screen</b>. The site must be opened with https.");
    card.appendChild(msg);

    overlay.appendChild(card);
    overlay.onclick = function (e) { if (e.target === overlay) close(); };
    document.body.appendChild(overlay);
  }

  function init() {
    var fab = el("button", "position:fixed;left:14px;bottom:14px;z-index:2147482000;border:0;border-radius:24px;padding:10px 16px;background:#FFD21F;color:#0E5A2A;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 3px 10px rgba(0,0,0,.3);font-family:system-ui,'Segoe UI',sans-serif", "&#11015; Download app");
    fab.id = "btDlBtn";
    fab.onclick = function () {
      if (!overlay) build();
      overlay.style.display = "flex";
    };
    document.body.appendChild(fab);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
