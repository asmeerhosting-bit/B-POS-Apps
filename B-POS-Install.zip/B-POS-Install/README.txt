B-POS install + download button

Upload everything to public_html with the same folders (back up first):
  install-app.js, manifest.json, sw.js, icon-192.png, icon-512.png
  index.html, billing.html, billing/index.html, admin/billing.html  (v19 pages + 4 lines in <head>)
  downloads/.htaccess, downloads/README.txt

Then:
 - A yellow "Download app" button appears bottom-left on the login/billing pages.
 - Install = browser install (needs manifest.json + sw.js uploaded, https).
 - Windows / Android buttons turn active when you upload B-POS-Setup.exe and B-POS.apk into public_html/downloads.
 - App name / file links: edit CFG at the top of install-app.js. App name and icon in the installed app: manifest.json + icon-192.png / icon-512.png.
If your live site is newer than v19, do not upload the 4 html files; paste snippet.txt after <head> in your own pages.
