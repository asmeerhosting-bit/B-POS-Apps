Put your built files in this folder (public_html/downloads), with exactly these names:
  B-POS-Setup.exe   (Windows installer)
  B-POS.apk         (Android app)
The "Download app" button on the site shows "Download" only when the file exists.
