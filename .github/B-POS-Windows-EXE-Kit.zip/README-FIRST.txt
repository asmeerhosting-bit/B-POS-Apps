B-POS Windows EXE  /  B-POS Windows EXE   (3 ways / 3 வழிகள்)
=============================================================
BEFORE ANYTHING: upload B-Pos-v48.zip to your server (cPanel). The "#shopkey=" auto-connect link needs v48 or newer.

WHAT EVERY OPTION DOES (same flow)
  Setup asks SERVER URL + SHOP KEY (SHOP_KEY from config.php) -> "Activate" checks the server and the key
  -> "Finish" writes config.json and creates Desktop + Start-menu shortcuts that open B-POS already connected.

OPTION A - get the real EXE files with NO Windows tools (GitHub builds them for you, free)   <-- recommended
  1. Make a free account at github.com -> New repository (Private) -> name: bpos-windows.
  2. Upload everything inside this ZIP to the repository (Add file > Upload files; drag the folders .github, B-POS-Windows, B-POS-Python).
     If the hidden folder ".github" is not uploaded: Add file > Create new file, type  .github/workflows/build-exe.yml  and paste the file from this zip.
  3. Open the "Actions" tab -> "Build B-POS Windows EXE" -> Run workflow. Wait about 3-5 minutes.
  4. Open the finished run -> Artifacts -> download  B-POS-Setup  (B-POS-Setup.exe = installer wizard) and  B-POS-App  (B-POS.exe = single-file app).
  Give B-POS-Setup.exe to the shops.

OPTION B - works at once, NO build: B-POS-NoBuild\B-POS-Setup.hta
  Copy the folder B-POS-NoBuild to the PC and double-click B-POS-Setup.hta -> type the Server URL + Shop Key -> Activate -> Finish.
  It installs to %LOCALAPPDATA%\B-POS (no administrator needed), writes config.json, creates the shortcuts and opens B-POS.
  Remove: run %LOCALAPPDATA%\B-POS\Uninstall.bat.   (.hta is not an .exe, Windows may ask "Do you want to open it?" - choose Open.)

OPTION C - build yourself on a Windows PC
  * Installer: install Inno Setup 6 -> open B-POS-Windows\B-POS-Setup.iss -> Build > Compile -> Output\B-POS-Setup.exe
  * Python app: install Python with python_manager_26_4.msix -> run B-POS-Python\build_online.bat (internet) or prepare_offline.bat + build_offline.bat (no internet) -> dist\B-POS.exe

NOT TESTED ON WINDOWS: these files were prepared on a Linux machine. The server check, the config.json writing and the shortcut text were tested with a simulated Windows (Option B logic) and the Python server-check code; the Inno compile, the GitHub run, PyInstaller and the Edge window were NOT run. If any step shows an error, send me the error text and I will fix it.
SECURITY: the Shop Key is saved in plain text in config.json and in the shortcut on that PC - install only on your own PCs (use a per-PC key from the Security page so you can switch one PC off).
