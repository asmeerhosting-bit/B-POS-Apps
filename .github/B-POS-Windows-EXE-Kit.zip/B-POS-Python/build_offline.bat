@echo off
rem ===== B-POS.exe - build WITHOUT internet (uses the "wheels" folder made by prepare_offline.bat) =====
cd /d "%~dp0"
if not exist wheels ( echo The "wheels" folder is missing - run prepare_offline.bat on a PC with internet first. & pause & exit /b 1 )
py -m pip install --no-index --find-links wheels -r requirements.txt || goto :err
py -m PyInstaller --noconfirm --clean --onefile --windowed --name B-POS --icon B-POS.ico --add-data "B-POS.ico;." bpos_app.py || goto :err
echo.
echo DONE:  dist\B-POS.exe
pause & exit /b 0
:err
echo BUILD FAILED - see the messages above.
pause & exit /b 1
