@echo off
rem ===== B-POS.exe - build WITH internet =====
rem Needs Python 3.10+ (install it with the Python Manager .msix you downloaded).
cd /d "%~dp0"
py -m pip install --upgrade pip
py -m pip install -r requirements.txt || goto :err
py -m PyInstaller --noconfirm --clean --onefile --windowed --name B-POS --icon B-POS.ico --add-data "B-POS.ico;." bpos_app.py || goto :err
echo.
echo DONE:  dist\B-POS.exe
pause & exit /b 0
:err
echo BUILD FAILED - see the messages above.
pause & exit /b 1
