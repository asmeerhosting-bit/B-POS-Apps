# -*- coding: utf-8 -*-
"""
B-POS desktop app (Windows) - Python.
 * First start: asks SERVER URL + SHOP KEY, tests them (Activate), writes config.json.
 * Next starts: opens B-POS already connected (no key prompt).
 * Online : opens your POS site in its own window (Microsoft Edge WebView2 via pywebview).
 * Offline: shows a waiting page, retries every 5 s and opens the POS the moment the server is reachable.
           (If the connection drops while you are working, the POS page itself keeps the sales and sends them later.)
Command line:  B-POS.exe --setup   (change server / key)     B-POS.exe --reset   (forget the saved connection)
"""
import json, os, sys, time, ssl, threading, urllib.request, urllib.error, webbrowser

APP = "B-POS"
HERE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
DATA = os.path.join(os.environ.get("APPDATA", HERE), APP)          # %APPDATA%\B-POS
CFG_PATHS = [os.path.join(HERE, "config.json"), os.path.join(DATA, "config.json")]   # next to the exe first (installer), then AppData

# ---------------------------------------------------------------- config
def load_config():
    for p in CFG_PATHS:
        try:
            with open(p, encoding="utf-8") as f:
                c = json.load(f)
            if c.get("server") and c.get("shopkey"):
                return c
        except Exception:
            pass
    return {}

def save_config(server, key):
    os.makedirs(DATA, exist_ok=True)
    cfg = {"server": server, "shopkey": key, "activated": True, "saved": time.strftime("%Y-%m-%d %H:%M")}
    with open(os.path.join(DATA, "config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return cfg

def reset_config():
    for p in CFG_PATHS:
        try: os.remove(p)
        except Exception: pass

def norm_url(u):
    u = (u or "").strip()
    if u and not u.lower().startswith(("http://", "https://")):
        u = "https://" + u
    return u.rstrip("/")

# ---------------------------------------------------------------- server check (same codes as the Windows installer)
# 0 OK | 2 not a B-POS server | 3 SHOP_KEY not set in config.php | 4 wrong Shop Key | 5 cannot reach the server
MSG = {
    0: "✔ Server found and Shop Key accepted. / சர்வர் + Key சரி.",
    2: "❌ This address is not a B-POS server (api.php not found). / இது B-POS சர்வர் அல்ல.",
    3: "❌ Server found, but SHOP_KEY is not set in config.php yet.",
    4: "❌ Wrong Shop Key. / தவறான Shop Key.",
    5: "⚠ Cannot reach the server. Check the internet and the address. / சர்வரை அடைய முடியவில்லை.",
}

def _get(url, headers=None, timeout=12):
    req = urllib.request.Request(url, headers=headers or {})
    ctx = ssl.create_default_context()
    return urllib.request.urlopen(req, timeout=timeout, context=ctx)

def check_server(url, key=None):
    """returns a code from MSG"""
    url = norm_url(url)
    try:
        with _get(url + "/api.php?action=ping") as r:
            j = json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError:
        return 2
    except Exception:
        return 5
    if j.get("app") != "BTPOS":
        return 2
    if not j.get("configured"):
        return 3
    if key is None:
        return 0
    try:
        with _get(url + "/api.php?action=get", {"X-Shop-Key": key}, timeout=25) as r:
            return 0 if r.status == 200 else 5
    except urllib.error.HTTPError as e:
        return 4 if e.code == 401 else 5
    except Exception:
        return 5

def is_online(url):
    return check_server(url) == 0

# ---------------------------------------------------------------- setup window (tkinter, ships with Python)
def setup_dialog(cur=None):
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception:
        return setup_console(cur)
    cur = cur or {}
    res = {}
    root = tk.Tk(); root.title("B-POS Setup / சர்வர் இணைப்பு"); root.geometry("520x330"); root.resizable(False, False)
    try: root.iconbitmap(os.path.join(HERE, "B-POS.ico"))
    except Exception: pass
    frm = ttk.Frame(root, padding=18); frm.pack(fill="both", expand=True)
    ttk.Label(frm, text="Server connection / சர்வர் இணைப்பு", font=("Segoe UI", 13, "bold")).pack(anchor="w")
    ttk.Label(frm, text="Type your POS website address and the SHOP_KEY from config.php, then press Activate.", wraplength=480).pack(anchor="w", pady=(2, 10))
    ttk.Label(frm, text="Server URL (e.g. https://pos.yourshop.lk)").pack(anchor="w")
    su = tk.StringVar(value=cur.get("server", "https://")); e1 = ttk.Entry(frm, textvariable=su, width=58); e1.pack(anchor="w", pady=(0, 8))
    ttk.Label(frm, text="Shop Key (SHOP_KEY)").pack(anchor="w")
    sk = tk.StringVar(value=cur.get("shopkey", "")); e2 = ttk.Entry(frm, textvariable=sk, show="•", width=58); e2.pack(anchor="w")
    show = tk.BooleanVar(value=False)
    ttk.Checkbutton(frm, text="Show key", variable=show, command=lambda: e2.config(show="" if show.get() else "•")).pack(anchor="w", pady=(2, 6))
    msg = tk.StringVar(); lab = ttk.Label(frm, textvariable=msg, wraplength=480); lab.pack(anchor="w", pady=4)
    btns = ttk.Frame(frm); btns.pack(anchor="w", pady=6)
    state = {"ok": False}
    def run_check():
        u, k = norm_url(su.get()), sk.get().strip()
        if len(k) < 6 or not u:
            msg.set("Enter the server URL and a Shop Key of 6+ characters."); return
        msg.set("Checking… / சரிபார்க்கிறது…"); root.update_idletasks()
        def work():
            code = check_server(u, k)
            def done():
                msg.set(MSG[code]); state["ok"] = (code == 0)
                go.config(state="normal" if code in (0, 5) else "disabled")
                go.config(text="Save & Open" if code == 0 else "Save anyway (offline)")
            root.after(0, done)
        threading.Thread(target=work, daemon=True).start()
    ttk.Button(btns, text="Activate / செயல்படுத்து", command=run_check).pack(side="left")
    def go_click():
        res["server"], res["shopkey"] = norm_url(su.get()), sk.get().strip(); root.destroy()
    go = ttk.Button(btns, text="Save & Open", command=go_click, state="disabled"); go.pack(side="left", padx=8)
    ttk.Button(btns, text="Cancel", command=root.destroy).pack(side="left")
    e1.focus_set(); root.mainloop()
    return res or None

def setup_console(cur=None):
    print("B-POS setup"); u = norm_url(input("Server URL: ")); k = input("Shop Key: ").strip()
    code = check_server(u, k); print(MSG[code])
    return {"server": u, "shopkey": k} if code in (0, 5) else None

# ---------------------------------------------------------------- window
OFFLINE_HTML = """<!doctype html><meta charset="utf-8"><title>B-POS</title>
<body style="font-family:Segoe UI,Arial,sans-serif;background:#eef6ea;color:#1b3a1b;text-align:center;padding-top:12vh">
<div style="font-size:64px">📡</div><h1>Offline / இணையம் இல்லை</h1>
<p>Waiting for the server… will open automatically. / சர்வருக்காகக் காத்திருக்கிறது…</p>
<p id="s" style="color:#6a7">__URL__</p>
<button onclick="chk()" style="padding:10px 22px;font-size:16px;border-radius:10px;border:0;background:#1f8f3a;color:#fff">Retry now / மீண்டும்</button>
<script>
var U="__URL__";
function chk(){ fetch(U+"/api.php?action=ping",{mode:"no-cors",cache:"no-store"}).then(function(){location.href="__OPEN__"}).catch(function(){document.getElementById("s").textContent=U+"  ✖  "+new Date().toLocaleTimeString()}) }
setInterval(chk,5000); chk();
</script></body>"""

def open_window(cfg):
    url, key = cfg["server"], cfg["shopkey"]
    open_url = f"{url}/#shopkey={key}"
    try:
        import webview
    except Exception:
        webbrowser.open(open_url); return
    if is_online(url):
        win = webview.create_window("B-POS", open_url, width=1280, height=800, min_size=(380, 520))
    else:
        html = OFFLINE_HTML.replace("__URL__", url).replace("__OPEN__", open_url)
        win = webview.create_window("B-POS (offline)", html=html, width=900, height=640)
    os.makedirs(os.path.join(DATA, "webview"), exist_ok=True)
    webview.start(private_mode=False, storage_path=os.path.join(DATA, "webview"))

def main():
    args = [a.lower() for a in sys.argv[1:]]
    if "--reset" in args:
        reset_config(); print("Saved connection removed."); return
    cfg = load_config()
    if "--setup" in args or not cfg:
        got = setup_dialog(cfg)
        if not got: return
        cfg = save_config(got["server"], got["shopkey"])
    open_window(cfg)

if __name__ == "__main__":
    main()
