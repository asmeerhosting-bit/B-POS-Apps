@echo off
rem ===== Run ONCE on a PC WITH internet: downloads everything needed into the "wheels" folder =====
cd /d "%~dp0"
py -m pip download -r requirements.txt -d wheels || goto :err
echo.
echo DONE. Copy this whole folder (with "wheels") to the offline PC and run build_offline.bat there.
echo (The offline PC needs the same Windows + Python version as this PC.)
pause & exit /b 0
:err
echo FAILED
pause & exit /b 1
