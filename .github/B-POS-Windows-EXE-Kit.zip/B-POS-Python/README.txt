B-POS Windows app - built with Python        /        Python மூலம் B-POS Windows செயலி
===================================================================================
WHAT YOU GET: one file  B-POS.exe
  1st start : asks SERVER URL + SHOP KEY -> "Activate" checks the server and the key -> saves config.json -> opens B-POS.
  Next starts: opens B-POS already connected (no Server Key prompt). Login with name + password / PIN.
  Offline    : if the server cannot be reached the app shows a waiting page and opens B-POS by itself when the internet is back.
  Change server / key :  B-POS.exe --setup        Forget the connection :  B-POS.exe --reset
  Config is saved in  %APPDATA%\B-POS\config.json  (a config.json placed NEXT TO B-POS.exe is used first - handy for an installer).

BUILD (on a Windows PC)
  0. Install Python: double-click python_manager_26_4.msix (Python Install Manager), then install Python 3.12 or newer with it.
  A) PC WITH internet : double-click  build_online.bat   -> dist\B-POS.exe
  B) PC WITHOUT internet:
       1. On any PC with internet run  prepare_offline.bat  (downloads the needed packages into the "wheels" folder).
       2. Copy this whole folder (with "wheels") to the offline PC (same Windows + same Python version) and run  build_offline.bat.
  Copy B-POS.exe to the shops - it needs no Python on the shop PC. Windows 10/11 has the Edge WebView2 runtime built in.

UPLOAD FIRST: the web files B-Pos-v48.zip must be on your server (the "#shopkey=" auto-activation link needs v48 or newer).
NOTE: the app opens the POS website, so the POS needs the server. Real offline selling after a drop is done by the POS page (it keeps the sales and sends them later); starting the app with no connection only shows the waiting page.
SECURITY: the Shop Key is stored in config.json (plain text) on that PC - install only on your own PCs.
NOT TESTED ON WINDOWS: the server check and the config code were tested here; the window (pywebview) and PyInstaller steps were not, because the build machine has no Windows.
