; ===== B-POS Windows setup (Inno Setup 6 - free: https://jrsoftware.org/isdl.php) =====
; Build: open this file in Inno Setup -> Build > Compile -> Output\B-POS-Setup.exe
; The wizard asks for the SERVER URL + SHOP KEY, tests them ("Activate"), and at Finish
; writes config.json and creates shortcuts that open B-POS already connected (no key prompt).

#define AppName "B-POS"
#define AppVer  "1.0"

[Setup]
AppId={{8F4C2A61-5B7D-4E9A-A1C3-0B5F6D7E8A90}
AppName={#AppName}
AppVersion={#AppVer}
AppPublisher=BestTaup | ARM.Asmi
DefaultDirName={autopf}\B-POS
DefaultGroupName=B-POS
DisableProgramGroupPage=yes
OutputBaseFilename=B-POS-Setup
SetupIconFile=B-POS.ico
UninstallDisplayIcon={app}\B-POS.ico
LicenseFile=license.txt
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut / Desktop shortcut உருவாக்கு"; Flags: checkedonce

[Files]
Source: "B-POS.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "Test-Connection.ps1"; Flags: dontcopy

[Icons]
Name: "{autoprograms}\B-POS"; Filename: "{code:BrowserExe}"; Parameters: "{code:BrowserParams}"; IconFilename: "{app}\B-POS.ico"
Name: "{autodesktop}\B-POS"; Filename: "{code:BrowserExe}"; Parameters: "{code:BrowserParams}"; IconFilename: "{app}\B-POS.ico"; Tasks: desktopicon

[Run]
Filename: "{code:BrowserExe}"; Parameters: "{code:BrowserParams}"; Description: "Launch B-POS / B-POS ஐ தொடங்கு"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: files; Name: "{app}\config.json"

[Code]
var
  ConnPage: TInputQueryWizardPage;
  TestBtn: TNewButton;
  TestMsg: TNewStaticText;
  Activated: Boolean;

function NormUrl(U: String): String;
begin
  U := Trim(U);
  while (Length(U) > 0) and (U[Length(U)] = '/') do
    Delete(U, Length(U), 1);
  Result := U;
end;

function RunTest(var Msg: String): Boolean;
var
  RC: Integer;
  Ps, Args: String;
begin
  Result := False;
  ExtractTemporaryFile('Test-Connection.ps1');
  Ps := ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe');
  Args := '-NoProfile -ExecutionPolicy Bypass -File "' + ExpandConstant('{tmp}\Test-Connection.ps1') +
          '" -Url "' + NormUrl(ConnPage.Values[0]) + '" -Key "' + Trim(ConnPage.Values[1]) + '"';
  if not Exec(Ps, Args, '', SW_HIDE, ewWaitUntilTerminated, RC) then
  begin
    Msg := 'PowerShell could not start.';
    exit;
  end;
  case RC of
    0: begin Msg := 'OK - server found and Shop Key accepted. / சர்வர் + Key சரி.'; Result := True; end;
    2: Msg := 'This address is not a B-POS server (api.php not found). / இது B-POS சர்வர் அல்ல.';
    3: Msg := 'Server found, but SHOP_KEY is not set in config.php yet.';
    4: Msg := 'Wrong Shop Key. / தவறான Shop Key.';
  else
    Msg := 'Cannot reach the server. Check the internet and the address. / சர்வரை அடைய முடியவில்லை.';
  end;
end;

procedure EditChange(Sender: TObject);
begin
  Activated := False;
end;

procedure TestBtnClick(Sender: TObject);
var
  M: String;
begin
  if (Pos('http', LowerCase(Trim(ConnPage.Values[0]))) <> 1) or (Length(Trim(ConnPage.Values[1])) < 6) then
  begin
    TestMsg.Font.Color := clRed;
    TestMsg.Caption := 'Enter the server URL (https://...) and a Shop Key of 6+ characters.';
    exit;
  end;
  TestMsg.Font.Color := clWindowText;
  TestMsg.Caption := 'Checking... / சரிபார்க்கிறது...';
  WizardForm.Refresh;
  Activated := RunTest(M);
  if Activated then TestMsg.Font.Color := clGreen else TestMsg.Font.Color := clRed;
  TestMsg.Caption := M;
end;

procedure InitializeWizard;
begin
  ConnPage := CreateInputQueryPage(wpSelectDir,
    'Server connection / சர்வர் இணைப்பு',
    'Enter your POS server address and Shop Key',
    'Type the website address of your POS and the SHOP_KEY from config.php, then press Activate.');
  ConnPage.Add('Server URL (e.g. https://pos.yourshop.lk):', False);
  ConnPage.Add('Shop Key (SHOP_KEY):', True);
  ConnPage.Values[0] := 'https://';
  ConnPage.Edits[0].OnChange := @EditChange;
  ConnPage.Edits[1].OnChange := @EditChange;

  TestBtn := TNewButton.Create(WizardForm);
  TestBtn.Parent := ConnPage.Surface;
  TestBtn.Caption := 'Activate / செயல்படுத்து';
  TestBtn.Left := 0;
  TestBtn.Top := ConnPage.Edits[1].Top + ConnPage.Edits[1].Height + ScaleY(14);
  TestBtn.Width := ScaleX(170);
  TestBtn.Height := ScaleY(26);
  TestBtn.OnClick := @TestBtnClick;

  TestMsg := TNewStaticText.Create(WizardForm);
  TestMsg.Parent := ConnPage.Surface;
  TestMsg.Left := 0;
  TestMsg.Top := TestBtn.Top + TestBtn.Height + ScaleY(10);
  TestMsg.Width := ConnPage.SurfaceWidth;
  TestMsg.AutoSize := False;
  TestMsg.WordWrap := True;
  TestMsg.Height := ScaleY(48);
  TestMsg.Caption := '';
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  M: String;
begin
  Result := True;
  if CurPageID = ConnPage.ID then
  begin
    if Pos('http', LowerCase(Trim(ConnPage.Values[0]))) <> 1 then
    begin
      MsgBox('Enter the server URL starting with https://', mbError, MB_OK);
      Result := False;
      exit;
    end;
    if Length(Trim(ConnPage.Values[1])) < 6 then
    begin
      MsgBox('The Shop Key must be at least 6 characters.', mbError, MB_OK);
      Result := False;
      exit;
    end;
    if not Activated then
    begin
      Activated := RunTest(M);
      if not Activated then
        Result := (MsgBox(M + #13#10#13#10 + 'Install anyway? (you can type the key later in the app)', mbConfirmation, MB_YESNO) = IDYES);
    end;
  end;
end;

{ ---- shortcuts: Edge (or Chrome) in app mode, opened with the Shop Key so it connects at once ---- }
function BrowserExe(Param: String): String;
begin
  Result := ExpandConstant('{commonpf32}\Microsoft\Edge\Application\msedge.exe');
  if FileExists(Result) then exit;
  Result := ExpandConstant('{commonpf64}\Microsoft\Edge\Application\msedge.exe');
  if FileExists(Result) then exit;
  Result := ExpandConstant('{commonpf64}\Google\Chrome\Application\chrome.exe');
  if FileExists(Result) then exit;
  Result := ExpandConstant('{commonpf32}\Google\Chrome\Application\chrome.exe');
  if FileExists(Result) then exit;
  Result := ExpandConstant('{win}\explorer.exe');
end;

function BrowserParams(Param: String): String;
var
  U: String;
begin
  U := NormUrl(ConnPage.Values[0]) + '/#shopkey=' + Trim(ConnPage.Values[1]);
  if Pos('explorer.exe', BrowserExe('')) > 0 then
    Result := '"' + U + '"'
  else
    Result := '--app="' + U + '"';
end;

function JsonEsc(S: String): String;
begin
  StringChangeEx(S, '\', '\\', True);
  StringChangeEx(S, '"', '\"', True);
  Result := S;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  J, A: String;
begin
  if CurStep = ssPostInstall then
  begin
    if Activated then A := 'true' else A := 'false';
    J := '{' + #13#10 +
         '  "server": "'   + JsonEsc(NormUrl(ConnPage.Values[0])) + '",' + #13#10 +
         '  "shopkey": "'  + JsonEsc(Trim(ConnPage.Values[1])) + '",' + #13#10 +
         '  "activated": ' + A + ',' + #13#10 +
         '  "installed": "' + GetDateTimeString('yyyy-mm-dd hh:nn', '-', ':') + '"' + #13#10 + '}';
    SaveStringToFile(ExpandConstant('{app}\config.json'), J, False);
  end;
end;
