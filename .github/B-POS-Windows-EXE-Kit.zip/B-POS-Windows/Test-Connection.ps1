# B-POS setup helper: checks the server address and the Shop Key.
# Exit codes: 0 = OK, 2 = not a B-POS server, 3 = SHOP_KEY not set in config.php, 4 = wrong Shop Key, 5 = cannot reach the server
param([string]$Url, [string]$Key)
$ErrorActionPreference = 'Stop'
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $u = $Url.TrimEnd('/')
  $p = Invoke-RestMethod -Uri "$u/api.php?action=ping" -TimeoutSec 15
  if ($p.app -ne 'BTPOS') { exit 2 }
  if (-not $p.configured) { exit 3 }
  try {
    $null = Invoke-WebRequest -Uri "$u/api.php?action=get" -Headers @{ 'X-Shop-Key' = $Key } -UseBasicParsing -TimeoutSec 25
  } catch {
    if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) { exit 4 }
    exit 5
  }
  exit 0
} catch { exit 5 }
