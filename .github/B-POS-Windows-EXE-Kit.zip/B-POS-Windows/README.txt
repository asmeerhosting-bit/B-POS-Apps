B-POS Windows setup  /  B-POS Windows நிறுவி
=============================================
WHAT IT DOES / என்ன செய்கிறது
 1. Welcome -> License -> Folder -> "Server connection" page: type your SERVER URL and SHOP KEY (SHOP_KEY from config.php) and press "Activate".
    Activate checks: the address is a B-POS server, config.php has a SHOP_KEY, and the key is accepted.
 2. Install. At Finish it WRITES  config.json  (server, shopkey, activated) in the install folder
    and creates Desktop + Start-menu shortcuts.
 3. The shortcuts open B-POS in its own window (Microsoft Edge / Chrome app mode) at
       https://your-site/#shopkey=YOUR_KEY
    The web app stores the key on that PC once and removes it from the address bar - NO "Server Key needed" prompt.
    The user only logs in with name + password / PIN.

HOW TO BUILD B-POS-Setup.exe (on a Windows PC)
 1. Install Inno Setup 6 (free): https://jrsoftware.org/isdl.php
 2. Open B-POS-Setup.iss -> Build > Compile.
 3. Result: Output\B-POS-Setup.exe (give this file to your shops).

IMPORTANT
 - Upload the new web files (B-Pos-v48.zip) to your server first: the "#shopkey=" link works only with v48 or newer.
 - The Shop Key is stored in config.json and in the shortcut (plain text) on that PC - install only on your own PCs.
   Use a per-PC key (Security page) if you want to be able to switch one PC off later.
 - If the PC has no Edge / Chrome the shortcut opens the default browser.
 - This .iss was written for Inno Setup 6 but could not be compiled on the machine that created it - if the compiler shows an
   error line, send me that line and I will fix it.
 - Tamil / Sinhala are shown on the Server connection page; the rest of the wizard uses Inno's built-in English text.
